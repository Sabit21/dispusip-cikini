-- phpMyAdmin SQL Dump
-- version 2.6.3-pl1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 22, 2023 at 11:23 AM
-- Server version: 4.1.13
-- PHP Version: 5.0.4
-- 
-- Database: `dispusip`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `agenda`
-- 

CREATE TABLE `agenda` (
  `id` int(5) NOT NULL auto_increment,
  `hari` varchar(100) NOT NULL default '',
  `judul` varchar(255) NOT NULL default '',
  `keterangan` text NOT NULL,
  `lokasi` varchar(255) NOT NULL default '',
  `waktu` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `agenda`
-- 

INSERT INTO `agenda` VALUES (4, 'Jum''at, 19 Mei 2023', 'Rapat', 'FGD Reformasi Birokrasi Tematik dan Reformasi Birokrasi General untuk mengoptimalkan Cita Provinsi DKI Jakarta untuk Indonesia Tahun 2023', 'Ruang Pola Bappeda Provinsi DKI Jakarta', '07:30- Selesai WIB');
INSERT INTO `agenda` VALUES (5, 'Jum''at, 19 Mei 2023', 'Rapat', 'Undangan Pengukuhan PD IPI Provinsi DKI Jakarta', 'Aula PDS HB Jassin', '13:00 - 15:00 WIB');

-- --------------------------------------------------------

-- 
-- Table structure for table `berita`
-- 

CREATE TABLE `berita` (
  `idberita` int(11) NOT NULL default '0',
  `judul` varchar(255) collate latin1_general_ci NOT NULL default '',
  `isi` text collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`idberita`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Dumping data for table `berita`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `gambar`
-- 

CREATE TABLE `gambar` (
  `id` int(11) NOT NULL auto_increment,
  `judul` varchar(255) collate latin1_general_ci NOT NULL default '',
  `gambar` varchar(255) collate latin1_general_ci NOT NULL default '',
  `size` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=35 ;

-- 
-- Dumping data for table `gambar`
-- 

INSERT INTO `gambar` VALUES (33, '', '2023-01-02 (1).jpg', 317920);
INSERT INTO `gambar` VALUES (34, '', 'IMG20200206114808.jpg', 129918);

-- --------------------------------------------------------

-- 
-- Table structure for table `lowongan`
-- 

CREATE TABLE `lowongan` (
  `id` int(11) NOT NULL auto_increment,
  `kategori` varchar(255) collate latin1_general_ci NOT NULL default '',
  `perusahaan` varchar(255) collate latin1_general_ci NOT NULL default '',
  `pekerjaan` varchar(255) collate latin1_general_ci NOT NULL default '',
  `syarat` text collate latin1_general_ci NOT NULL,
  `kontak` varchar(255) collate latin1_general_ci NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=21 ;

-- 
-- Dumping data for table `lowongan`
-- 

INSERT INTO `lowongan` VALUES (20, '', 'Idul Fitri', 'Selamat Hari Raya Idul Fitri 1444 H " Mohon Maaf Lahir dan Batin', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `pengumuman`
-- 

CREATE TABLE `pengumuman` (
  `id` int(11) NOT NULL auto_increment,
  `pengumuman` text collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `pengumuman`
-- 

INSERT INTO `pengumuman` VALUES (1, 'Pengumuman');

-- --------------------------------------------------------

-- 
-- Table structure for table `video`
-- 

CREATE TABLE `video` (
  `id` int(11) NOT NULL auto_increment,
  `judul` varchar(255) collate latin1_general_ci NOT NULL default '',
  `video` varchar(255) collate latin1_general_ci NOT NULL default '',
  `durasi` bigint(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=24 ;

-- 
-- Dumping data for table `video`
-- 

INSERT INTO `video` VALUES (14, 'undian', 'undian-31.flv', 31);
INSERT INTO `video` VALUES (15, 'peterpan', 'peterpan-268.flv', 268);
INSERT INTO `video` VALUES (13, 'ksa', 'ksa31.flv', 31);
INSERT INTO `video` VALUES (12, 'dep', 'dep.flv', 31);
INSERT INTO `video` VALUES (11, 'psmensos', 'psmensos.flv', 36);
INSERT INTO `video` VALUES (16, 'siagabencana', 'siagabencana-31.flv', 31);
INSERT INTO `video` VALUES (17, 'k3', 'k3-319.flv', 319);
INSERT INTO `video` VALUES (18, 'trans', 'trans.flv', 120);

-- --------------------------------------------------------

-- 
-- Table structure for table `warnabg`
-- 

CREATE TABLE `warnabg` (
  `id` int(11) NOT NULL default '0',
  `warna` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `warnabg`
-- 

INSERT INTO `warnabg` VALUES (1, 'F3F3F3');
INSERT INTO `warnabg` VALUES (2, 'Default.jpg');
